<?php include('inc/fonctions.php'); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd"> 
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<script src="js/tinymce/tinymce.min.js"></script>
<script src="js/bootstrap.file-input.js"></script>
<?php include('js/script_serveur.php'); ?>
<script>
$( document ).ready(function() {
$('input[type=file]').bootstrapFileInput();
});
</script>
</head>
<body style="background-color:#FFEEEE;padding-left:10px;padding-right:10px">
<h1 align="center">GESTION DE L'ECRAN D'AFFICHAGE DU TEXTE DE L'ANNEE</h1>
<br>
<h2 align="center">SALLE PRINCIPALE</h2>
<br>
<?php if(!isset($_SESSION['user_id'])) { ?>
<div align="center">
<form method="post">
<table>
	<tr>
		<td>Nom d'utilisateur : </td>
		<td><input type="text" name="login_username" /></td>
	</tr>
	<tr>
		<td><br></td>
	</tr>
	<tr>
		<td>Mot de passe : </td>
		<td><input type="password" name="login_password" /></td>
	</tr>
	<tr>
		<td><br></td>
	</tr>
	<tr>
		<td colspan="2" align="center"><input type="submit" class="btn btn-success" name="login_submit" value="Je me connecte" /></td>
	</tr>
</table>
</form>
</div>
<?php } else { ?>
<div align="right">
	<button style="display:inline" align="right" class="btn btn-warning parameters_edit" name="user">Paramètres</button>&nbsp;&nbsp;
	<button style="display:inline" align="right" class="btn btn-warning user" name="user">Gérer les utilisateurs</button>&nbsp;&nbsp;
	<form style="display:inline" method="post">
		<button class="btn btn-danger" name="halt">Eteindre l'écran</button>&nbsp;&nbsp;
		<button class="btn btn-danger" name="reboot">Redémarrer l'écran</button>&nbsp;&nbsp;
		<button class="btn btn-danger" name="logoff">Se déconnecter</button>
	</form>
</div>
<br>
<div class="edit_user" style="display:none;float:right;border:1px solid;padding: 5px 5px 5px 5px">
<h4 align="center">Utilisateurs</h4>
<?php
	$stmt = $dbh->prepare('SELECT * FROM user WHERE id>1');
	$stmt->execute();
	$liste = $stmt->fetchAll();
?>
<?php foreach($liste as $result) { ?>
<span class="glyphicon glyphicon-pencil user_edit" value="<?php echo $result['id']; ?>">&nbsp;<?php echo $result['username']; ?></span>
<br>
<?php } ?>
<form method="post">
<table>
	<tr>
		<td>Nom d'utilisateur : </td>
		<td><input type="text" id="username" name="username" /></td>
	</tr>
	<tr class="password_edit" style="display:none">
		<td colspan="2"><input type="checkbox" class="edit_password" />&nbsp;Changer le mot de passe</td>
	</tr>
	<tr class="password">
		<td>Mot de passe : </td>
		<td><input type="text" id="password" name="password" /></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td align="center" colspan="2">
			<button class="btn btn-success" name="user_edit">Enregistrer</button>
			<button class="btn btn-danger" id="user_delete" style="display:none" name="user_delete">Supprimer</button>
		</td>
	</tr>
</table>
<input type="hidden" id="user_id" name="user_id" value="" />
</form>
</div>
<div class="edit_parameters" style="display:none;float:right;border:1px solid;padding: 5px 5px 5px 5px">
<h4 align="center">Paramètres</h4>
<form method="post">
<table>
	<tr>
		<td>Nom de l'écran : </td>
		<td><input type="text" id="client_name" name="client_name" /></td>
	</tr>
	<tr>
		<td>Serveur / Client? : </td>
		<td><select name="mode" id="mode">
			<option value="0">Client</option>
			<option value="1">Serveur</option>
		</select></td>
	</tr>
	<tr>
		<td>Adresse du serveur : </td>
		<td><input type="text" id="server_address" name="server_address" /></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td align="center" colspan="2">
			<button class="btn btn-success" name="parameters_edit">Enregistrer</button>
		</td>
	</tr>
</table>
</form>
</div>
<br>
<?php
	$stmt = $dbh->prepare('SELECT * FROM layout WHERE active=1');
	$stmt->execute();
	$liste = $stmt->fetchAll();
?>
<table>
<?php foreach($liste as $result) { ?>
	<tr>
		<td>
			<form method="post">
				<button class="btn btn-success" name="print">Afficher sans l'heure</button>
				<input type="hidden" name="layout_id" value="<?php echo $result['id']; ?>" />
			</form>
		</td>
		<td>&nbsp;</td>
		<td>
			<form method="post">
				<button class="btn btn-info" name="print">Afficher avec l'heure</button>
				<input type="hidden" name="layout_id" value="<?php echo $result['id']; ?>" />
				<input type="hidden" name="datetime" id="datetime">
			</form>
		</td>
		<td>&nbsp;</td>
		<td><button class="btn btn-warning layout_show" name="edit" value="<?php echo $result['id']; ?>">Voir</button></td>
		<td>&nbsp;</td>
		<td><button class="btn btn-danger layout_hide layout_delete" name="delete" value="<?php echo $result['id']; ?>">Supprimer</button></td>
		<td>&nbsp;</td>
		<td><form><?php echo $result['name']; ?></form></td>
		<td>&nbsp;</td>
		<td>
			<form method="post" style="display:inline">
				<button class="btn btn-danger layout_hide delete_confirm delete_confirm_<?php echo $result['id']; ?>" name="delete_confirm" value="<?php echo $result['id']; ?>">Confirmer la suppression</button>
			</form>
		</td>
	</tr>
	<tr>
			<td><br></td>
	</tr>
<?php } ?>
</table>
<br />
<form method="post" class="submit_data" style="display:inline" id="upload_image" enctype="multipart/form-data" >
<table>
	<tr>
		<td><input data-filename-placement="inside" type="file" class="btn-primary" title="Choisir une image à afficher" id="picture_file" name="picture_file" accept=".png,.jpg" /></td>
		<td>&nbsp;</td>
		<td><input type="submit" class="btn btn-warning" name="show_picture" value="Afficher cette image" /></td>
	</tr>
</table>
</form>
<br />
<form method="post" class="submit_data" style="display:inline" id="upload_video" enctype="multipart/form-data" >
<table>
	<tr>
		<td><input data-filename-placement="inside" type="file" class="btn-primary" title="Choisir une vidéo à afficher" id="video_file" name="video_file" accept=".mp4" /></td>
		<td>&nbsp;</td>
		<td><input type="submit" class="btn btn-warning" name="show_video" value="Afficher cette vidéo" /></td>
	</tr>
</table>
</form>
<br />
<div><button class="btn btn-default layout_add" name="add">Créer un nouveau texte</button></div>
<br />
<div class="layout_edit">
	<form method="post" id="submit">
		<table width="100%">
			<tr>
				<td width="7%">Nom : </td>
				<td><input type="text" name="name" id="name" size="50" /></td>
			</tr>
			<tr>
				<td><br></td>
			</tr>
			<tr>
				<td>Texte : </td>
				<td><textarea id="texte" name="texte"></textarea></td>
			</tr>
			<tr>
				<td><br></td>
			</tr>
			<tr>
				<td>Date/Heure? : </td>
				<td><input type="checkbox" name="datetime" id="datetime"></td>
			</tr>
			<tr>
				<td><br></td>
			</tr>
			<tr>
				<td colspan="2" align="left">
					<button class="btn btn-success" name="record_and_update">Enregistrer et mettre à jour l'écran</button>
					&nbsp;&nbsp;
					<button class="btn btn-info">Enregistrer sans mettre à jour l'écran</button>
				</td>
			</tr>
			<input type="hidden" id="id" name="id" value="" />
			<input type="hidden" id="action" name="action" value="" />
		</table>
	</form>
</div>
</body>
<script>
$('.delete_confirm').toggle();
<?php if(!isset($_POST['id']) or (isset($_POST['id']) and $_POST['id']=="")) { ?>
$('.layout_edit').toggle();
<?php } ?>
</script>
</html>
<?php } ?>